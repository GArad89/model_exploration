# README #

### How do I get set up? ###

* install python 3
* install pip
* run pip install -r requirements.txt
  * Alternatively, you can install those packages on your own.
