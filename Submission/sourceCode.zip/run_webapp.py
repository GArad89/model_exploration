import os
import sys
from webapp import app


def main():
    app.run(debug=True)

if __name__=='__main__':
    main()

