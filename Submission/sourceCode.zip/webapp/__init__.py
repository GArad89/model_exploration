# does all setup
import webapp.views as views

app = views.app

